
/**
 * Write a description of class CashRegister here.
 *
 * @author Brian
 * @version (a version number or a date)
 */
public class CashRegister
{
    public static final double TAX_RATE = 0.06;
    // instance variables - replace the example below with your own
    private RetailItem item;
    private int quantitySold;

    /**
     * Constructor for objects of class CashRegister
     */
    public CashRegister(RetailItem inputItem, int numberOfSold)
    {
        // initialise instance variables
        setItem(inputItem);
        setQuantitySold(numberOfSold);
    }

    /**
     * Accessor method getItem()
     *
     * @return   item
     */
    public RetailItem getItem(){
        return item;
    }

    /**
     * Accessor method getQuantitySold()
     *
     * @return  quantitySold
     */
    public int getQuantitySold(){
        return quantitySold;
    }

    /**
     * Mutator method setQuantitySold()
     *
     * @param numberOfSold to set quantitySold
     */
    public void setQuantitySold(int numberOfSold){
        if(numberOfSold > 0 && numberOfSold <= item.getNumberOfUnitsInStock()){
            quantitySold = numberOfSold;
        }else{
            quantitySold = quantitySold;
        }
    }

    /**
     * Mutator method setItem()
     *
     * @param inputItem to set item
     */
    public void setItem(RetailItem inputItem){
        if(inputItem == null){
            item = new RetailItem();
        }else{
            item = inputItem;
        }
    }

    /**
     * Method calculateSubTotal()
     *
     * @return  subTotalCost
     */
    public double calculateSubTotal(){
        double subTotalCost = 0.0;
        subTotalCost = quantitySold * item.getItemPriceInCAD();
        return subTotalCost;
    }

    /**
     * Method calculateTax()
     *
     * @return tax
     */
    public double calculateTax(){
        double tax = 0.0;
        tax = calculateSubTotal() * TAX_RATE;
        return tax;
    }

    /**
     * Method calculateTotal()
     *
     * @return total
     */
    public double calculateTotal(){
        double total = 0.0;
        total = calculateSubTotal() + calculateTax();
        return total;
    }

    public void printSalesReceipt(){
        System.out.println("Item Description: " + item.getItemDescription());
        System.out.println("Unit price: " + item.getItemPriceInCAD());
        System.out.println("Quantity: " + quantitySold);
        System.out.println("Subtotal: $" + calculateSubTotal());
        System.out.println("Tax amount: " + calculateTax());
        System.out.println("Total: $" + calculateTotal());
    }
}
