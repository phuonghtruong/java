
/**
 * Write a description of class Driver here.
 *
 * @author Brian Truong
 * @version (a version number or a date)
 */
public class Driver
{
    // instance variables - replace the example below with your own
    private String driverName;
    private String driverLicenseNumber;
    private double speedInKilometerPerHour;
    private String driverStanding;

    /**
     * Constructor for objects of class Driver
     * @param name set driverName
     * @param licenseNumber set driverLicenseNumber
     * @param speed set speedInKilometerPerHour
     */
    public Driver(String name, String licenseNumber, double speed)
    {
        // initialise instance variables
        if(name != null){
            driverName = name;
        }else{
            throw new IllegalArgumentException("Driver name cannot be null");
        }
        
        if(licenseNumber != null){
            driverLicenseNumber = licenseNumber;
        }else{
            throw new IllegalArgumentException("License number cannot be null");
        }
        
        if(speed > 0){
            speedInKilometerPerHour = speed;
        }else {
            throw new IllegalArgumentException("Speed must be positive and greater than 0");
        }
        
        driverStanding = "unknown";
    }
    
    /**
     *  Set driver name
     *  @param name set driverName
     */
    public void setDriverName(String name){
        if(name != null){
            driverName = name;
        }else{
            throw new IllegalArgumentException("Driver name cannot be null");
        }
    }
    
    /**
     * Get driver name
     * @return driverName
     */
    public String getDriverName(){
        return driverName;
    }
    
    /**
     * Set driver license number
     * @param licenseNumber set driverLicenseNumber
     */
    public void setDriverLicenseNumber(String licenseNumber){
        if(licenseNumber != null){
            driverLicenseNumber = licenseNumber;
        }else{
            throw new IllegalArgumentException("License number cannot be null");
        }
    }
    
    /**
     * Get driver license number
     * @return driverLicenseNumber
     */
    public String getDriverLicenseNumber(){
        return driverLicenseNumber;
    }
    
    /**
     * Set speed in Kilometer per Hour
     * @param speed set speedInKilometerPerHour
     */
    public void setSpeedInKilometerPerHour(double speed){
        if(speed > 0){
            speedInKilometerPerHour = speed;
        }else {
            throw new IllegalArgumentException("Speed must be positive and greater than 0");
        }
    }
    
    /**
     * Get speed in Kilometer per hour
     * @return speedInKilometerPerHour
     */
    public double getSpeedInKilometerPerHour(){
        return speedInKilometerPerHour;
    }
    
    /**
     * 
     */
    public void setDriverStanding(){
        if(speedInKilometerPerHour > 80 ){
            driverStanding = "big ticket";
        } else if(speedInKilometerPerHour > 60){
            driverStanding = "small ticket";
        } else{
            driverStanding = "no ticket";
        }
    }
    
    /**
     * Get driver standing
     * @return driverStanding
     */
    public String getDriverStanding(){
        return driverStanding;
    }
    
    public void printDriverDetails(){
        System.out.println("Driver name: " + driverName);
        System.out.println("Driver License Number: " + driverLicenseNumber);
        System.out.println("Speed: " + speedInKilometerPerHour + " K/H");
        System.out.println("Driver Standing: " + driverStanding);
    }
    
    
    
    
    
    
    
    
    
}
