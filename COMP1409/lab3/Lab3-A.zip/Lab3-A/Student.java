
/**
 * Write a description of class Student here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Student
{
    // instance variables - replace the example below with your own
    private String studentName;
    private String studentID;
    private double studentTestScore;
    private double courseFeesInCAD;
    private boolean isEligibleForADiscount;

    /**
     * Constructor for objects of class Student
     * @param inputName set studentName
     * @param inputID set studentID
     * @param inputTestScore set studentTestScore
     * @param inputFee set courseFeesInCAD
     */
    public Student(String inputName, String inputID, double inputTestScore, double inputFee)
    {
        // initialise instance variables
        if(inputName != null){
            studentName = inputName;
        } else{
            throw new IllegalArgumentException("Name cannot be null");
        }
        if(inputID != null){
            studentID = inputID;
        }else{
            throw new IllegalArgumentException("ID cannnot be null");
        }
        if(inputTestScore > 0){
            studentTestScore = inputTestScore;
        } else{
            throw new IllegalArgumentException("Test score cannnot be negative");
        }
        if(inputFee > 0){
            courseFeesInCAD = inputFee;
        } else{
            throw new IllegalArgumentException("Course fee cannot be negative");
        }
        isEligibleForADiscount = false;
    }
    /**
    * Set student name
    * @param inputName set studentName
    */
    public void setStudentName(String inputName){
        if(inputName != null){
            studentName = inputName;
        } else{
            throw new IllegalArgumentException("Name cannot be null");
        }
    }
    
    /**
     * Set student ID
     * @param inputID set studentID
     */
    public void setStudentID(String inputID){
        if(inputID != null){
            studentID = inputID;
        }else{
            throw new IllegalArgumentException("ID cannnot be null");
        }
    }
    
    /**
     * set Test Score
     * @param inputTestScore set studentTestScore
     */
    public void setTestScore(double inputTestScore){
        if(inputTestScore > 0){
            studentTestScore = inputTestScore;
        } else{
            throw new IllegalArgumentException("Test score cannnot be negative");
        }
    }
    
    /**
     * set coures fee in CAD
     * @param inputFee set courseFeesInCAD
     */
    public void setCourseFeeInCAD(double inputFee){
        if(inputFee > 0){
            courseFeesInCAD = inputFee;
        } else{
            throw new IllegalArgumentException("Course fee cannot be negative");
        }
    }
    
    /**
     * set Eligible for Discount
     * @param isEligible set isEligibleForADiscount
     */
    public void setEligibleForADiscount(boolean isEligible){
        isEligibleForADiscount = isEligible;
    }
    
    /**
     * get student name
     * @return studentName
     */
    public String getStudentName(){
        return studentName;
    }
    
    /**
     * get student ID
     * @return studentID
     */
    public String getStudentID(){
        return studentID;
    }
    
    /**
     * get Test Score
     * @return studentTestScore
     */
    public double getTesScore(){
        return studentTestScore;
    }
    
    /**
     * get Course Fee
     * @return courseFeesInCAD
     */
    public double getCourseFee(){
        return courseFeesInCAD;
    }
    
    /**
     * get Eligible For A Discount
     * @return isEligibleForADiscount
     */
    public boolean getIsEligibleForADiscount(){
        return isEligibleForADiscount;
    }
    
    /**
     * Method check for Discount
     */
    public void checkForDiscount(){
        if( courseFeesInCAD >= 700){
            courseFeesInCAD = courseFeesInCAD * (1 - 0.15);
            isEligibleForADiscount = true;
        }else{
            isEligibleForADiscount = false;
        }
    }
    
    /**
     * Method print student details
     */
    public void printStudentDetails(){
        System.out.println("Student Name: " + studentName);
        System.out.println("Student ID: " + studentID);
        System.out.println("Test Score: " + studentTestScore);
        System.out.println("Course Fees: " + courseFeesInCAD);
        if(isEligibleForADiscount){
            System.out.println("This student got a discount of 15%");
        } else{
            System.out.println("This student does not get a discount");
        }
    }
    
    
    
    
    
    
    
    
    
    
    
}
