
/**
 * Write a description of class BankCharges here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class BankCharges
{
    // Symbolic constants
    public static final double FIRST_CHEQUES_CHARGE = 0.10;
    public static final double SECOND_CHEQUES_CHARGE = 0.08;
    public static final double THIRD_CHEQUES_CHARGE = 0.06;
    public static final double FOURTH_CHEQUES_CHARGE = 0.04;
    
    public static final int BANK_CHARGE = 10;
    public static final int BANK_LOW_BALANCE_CHARGE = 15;
    public static final int LOW_BALANCE_LIMIT = 400;
    
    public static final int FIRST_CHEQUES_LEVEL = 20;
    public static final int SECOND_CHEQUES_LEVEL = 40;
    public static final int THIRD_CHEQUES_LEVEL = 60;
    
    // instance variables - replace the example below with your own
    private String clientName;
    private double endingBalance;
    private int numberOfCheques;

    /**
     * Constructor for objects of class BankCharges
     */
    public BankCharges()
    {
        // initialise instance variables
        clientName = "unknown";
        endingBalance = 0.0;
        numberOfCheques = 0;
    }
    
    public BankCharges(String cName, double cEndingBalance, int cNumberOfCheques){
        if(cName != null){
            clientName = cName;
        }else{
            throw new IllegalArgumentException("client name cannot be null");
        }
        
        if(cEndingBalance < 0){
            throw new IllegalArgumentException("ending balance must be positive");
        }else{
            endingBalance = cEndingBalance;
        }
        
        if(cNumberOfCheques < 0){
            throw new IllegalArgumentException("number of cheques must be positive");
        }else{
            numberOfCheques = cNumberOfCheques;
        }
    }
    
    /**
     * Accessor method for client name
     * @return clientName
     */
    public String getClientName(){
       return clientName;
    }
    
    /**
     * Accessor method for client ending balance
     * @return endingBalance
     */
    public double getEndingBalance(){
        return endingBalance;
    }
    
    /**
     * Accessor method for number of cheques
     * @return numberOfCheques
     */
    public int getNumberOfCheques(){
        return numberOfCheques;
    }
    
    /**
     * Mutator  method for client name
     * @param clientName to set clientName
     */
    public void setClientName(String cName){
        if(cName != null){
            clientName = cName;
        }else{
            throw new IllegalArgumentException("client name cannot be null");
        }
    }
    
    /**
     * Mutator method for ending balance
     * @param cEndingBalance to set endingBalance
     */
    public void setEndingBalance(double cEndingBalance){
        if(cEndingBalance < 0){
            throw new IllegalArgumentException("ending balance must be positive");
        }else{
            endingBalance = cEndingBalance;
        }
    }
    
    /**
     * Mutator method for number of cheques
     * @param cNumberOfCheques to set numberOfCheques
     */
    
    public void setNumberOfCheques(int cNumberOfCheques){
        if(cNumberOfCheques < 0){
            throw new IllegalArgumentException("number of cheques must be positive");
        }else{
            numberOfCheques = cNumberOfCheques;
        }
    }
    
    /**
     * An example of a method - replace this comment with your own
     *
     * 
     * @return serviceFee to return service fee
     */
    public double calculateBankServiceFees()
    {
        // put your code here
        double serviceFee = BANK_CHARGE;
        
        //charges for low balance
        
        if(endingBalance < LOW_BALANCE_LIMIT){
            serviceFee += BANK_LOW_BALANCE_CHARGE;
        }
        
        //charges for number of cheques
        
        if(numberOfCheques >= THIRD_CHEQUES_LEVEL){
            serviceFee += FOURTH_CHEQUES_CHARGE * numberOfCheques;
        }else if(numberOfCheques >= SECOND_CHEQUES_LEVEL){
            serviceFee += THIRD_CHEQUES_CHARGE * numberOfCheques;
        }else if(numberOfCheques >= FIRST_CHEQUES_LEVEL){
            serviceFee += SECOND_CHEQUES_CHARGE * numberOfCheques;
        }else{
            serviceFee += FIRST_CHEQUES_CHARGE * numberOfCheques;
        }
        
        //Deduct ending blance;
        endingBalance -= serviceFee;
        
        return serviceFee;
    }
}
