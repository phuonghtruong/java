
/**
 * Write a description of class FuelGauge here.
 *
 * @author Brian
 * @version (a version number or a date)
 */
public class FuelGauge
{
    // instance variables - replace the example below with your own
    public static final int FULL_TANK = 15;
    public static final int EMPTY_TANK = 0;
    
    private int amountOfFuelInLitres;

    /**
     * Constructor for objects of class FuelGauge
     */
    public FuelGauge(){
        amountOfFuelInLitres = 0;
    }
    
    public FuelGauge(int amountOfFuelInLitres)
    {
        // initialise instance variables
        setAmountOfFuelInLitres(amountOfFuelInLitres);
    }
    
    /**
     * Mutator method for setAmountOfFuelInLitres
     * @para amountOfFuelInLitres
     */
    public void setAmountOfFuelInLitres(int amountOfFuelInLitres){
        if( amountOfFuelInLitres > 0 && amountOfFuelInLitres <= FULL_TANK )
                this.amountOfFuelInLitres = amountOfFuelInLitres;
        else
            throw new IllegalArgumentException("amount must be in range 0 to 15");
    }
    
    /**
     * Accessor method getAmountOfFuelInLitres
     * @return amountOfFuelInLitres
     */
    public int getAmountOfFuelInLitres(){
        return amountOfFuelInLitres;
    }
   
    public void useFuel()
    {
        // put your code here
        if(getAmountOfFuelInLitres() > EMPTY_TANK)
            amountOfFuelInLitres -= 1;
        else
            System.out.println("the tank is empty the fuel cannot go below 0");
    }
    
    public void addFuel()
    {
        // put your code here
        if(getAmountOfFuelInLitres() >= FULL_TANK)
            System.out.println("the tank is full the fuel cannot go over 15");      
        else
            amountOfFuelInLitres += 1;
    }
    
}
