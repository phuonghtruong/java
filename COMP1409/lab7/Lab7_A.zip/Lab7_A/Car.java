
/**
 * Write a description of class Car here.
 *
 * @author Brian
 * @version (a version number or a date)
 */
public class Car
{
    // instance variables - replace the example below with your own
    String carMake;
    String carColour;
    FuelGauge fuelGauge;

    /**
     * Constructor for objects of class Car
     */
    public Car()
    {
        // initialise instance variables
        carMake = new String("unknown");
        carColour = new String("unknown");
        FuelGauge fuelGauge = new FuelGauge();
    }
    /**
     * Constructor
     * @para inputMake to set carMake
     * @para inputColour to set carColour
     * @para fuelAmount to set fuel amount for object fuelGauge
     */
    public Car(String inputMake, String inputColour, int fuelAmount)
    {
        setCarMake(inputMake);
        setCarColour(inputColour);
        setFuelGauge(fuelAmount);
    }
    /**
     * Mutator method setCarMake
     * @para inputMake to set carMake
     */
    public void setCarMake(String inputMake){
        if(inputMake.equals("null"))
            throw new IllegalArgumentException("car make cannot be null");
        else
            carMake = inputMake;
    }
    
    /**
     * Mutator method setCarColour
     * @para inputColour to set carColour
     */
    public void setCarColour(String inputColour){
        if(inputColour.equals("null"))
            throw new IllegalArgumentException("car color cannot be null");
        else
            carColour = inputColour;
    }
    
    /**
     * Mutator method setFuelGauge
     * @para fuelAmount to set fuel amount
     */
    public void setFuelGauge(int fuelAmount){
        if(fuelAmount == 0)
            fuelGauge = new FuelGauge();
        else
            fuelGauge = new FuelGauge(fuelAmount);
    }
    
    /**
     * accessor method getCarMake
     * @return carMake
     */
    public String getCarMake(){
        return carMake;
    }
    
    /**
     * accessor method getCarColour
     * @return carColour
     */
    public String getCarColour(){
        return carColour;
    }
    
    /**
     * accessor method getFuelGauge
     * @return fuelGauge
     */
    public FuelGauge getFuelGauge(){
        return fuelGauge;
    }
    
    /**
     * drive method
     */
    public void drive(){
        fuelGauge.useFuel();
    }
    
    /**
     * fillTank method
     */
    public void fillTank(){
        fuelGauge.addFuel();
    }
}
