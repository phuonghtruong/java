
/**
 * Write a description of class Employee here.
 *
 * @author Brian
 * @version (a version number or a date)
 */
public class Employee
{
    // instance variables - replace the example below with your own
    private String employeeName;
    private int employeeAgeInYears;
    private String employeeAddress;
    private int numberOfYearsEmployed;
    private double annualPayInCAD;
    private boolean isFullTime;

    /**
     * Employee Constructor
     * no parameter
     */
    public Employee()
    {
        // initialise instance variables
        employeeName = "unknown";
        employeeAgeInYears = 1;
        employeeAddress = "unknown";
        numberOfYearsEmployed = 1;
        annualPayInCAD = 1;
        isFullTime = false;
    }
    
    /**
     * Employee Constructor
     * @param name to set employeeName
     * @param age to set employeeAgeInYears
     * @param address to set employeeAddress
     * @param yearsOfEmployed to set numberOfYearEmployed
     * @param payInCAD to set annualPayInCAD
     * @param fullTime to set isFullTime
     */
    public Employee(String name, int age, 
                    String address, int yearsOfEmployed, 
                    double payInCAD, boolean fullTime){
        if(name != null){
            employeeName = name;
        } else {
            throw new IllegalArgumentException("Name cannot be null");
        }
        
        if(age <= 0 && age > 100){
            throw new IllegalArgumentException("Age must be greater than 0");
        } else{
            employeeAgeInYears = age;
        }
        
        if(address != null){
            employeeAddress = address;
        } else{
            throw new IllegalArgumentException("Address cannot be null");
        }
        
        if(yearsOfEmployed <= 0){
            throw new IllegalArgumentException("Years of Employed must be greater than 0");
        } else{
            numberOfYearsEmployed = yearsOfEmployed;
        }
        
        if(payInCAD <= 0){
            throw new IllegalArgumentException("Annual pay in CAD must be greater than 0");
        } else{
            annualPayInCAD = payInCAD;
        }
        
        isFullTime = fullTime;
    }
    
    
}
