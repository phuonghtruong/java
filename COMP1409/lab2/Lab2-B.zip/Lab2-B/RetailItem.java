
/**
 * Write a description of class RetailItem here.
 *
 * @author Brian
 * @version (a version number or a date)
 */
public class RetailItem
{
    // instance variables - replace the example below with your own
    private String itemDescription;
    private double itemPriceInCAD;
    private boolean isInDemand;
    private int numberOfUnitsInStock;
    
    /**
     * Constructor for objects of class RetailItem
     * No parameter
     */
    public RetailItem()
    {
        // initialise instance variables
        itemDescription = "unknown";
        itemPriceInCAD = 1;
        isInDemand = false;
        numberOfUnitsInStock = 1;
    }

    /**
     * constructor RetailItem
     *
     * @param  description to set itemDescription
     * @param price to set itemPriceInCAD
     * @param inDemand to set isInDemand
     * @param numberOfUnits to set numberOfUnitsInStock
     */
    public RetailItem(String description, double price, boolean inDemand,
                        int numberOfUnits)
    {   
        if(description != null){
            itemDescription = description;
        } else {
            throw new IllegalArgumentException("Description cannot be null");
        }
        
        if(price > 0){
            itemPriceInCAD = price;
        } else{
            throw new IllegalArgumentException("Price cannot be negative");
        }
        
        if(numberOfUnits > 0){
            numberOfUnitsInStock = numberOfUnits;
        } else{
            throw new IllegalArgumentException("Number of units cannot be negative");
        }
        
        isInDemand = inDemand;
    }
}
