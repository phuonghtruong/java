package ca.bcit.comp2526.assign3;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.function.Function;

public class IntegerAccumulator implements Accumulator<Integer, Integer> {

    Map<Integer, Integer> intMap;

    public IntegerAccumulator()
    {
        intMap = new HashMap<>();
        intMap.put(0,0);
    }

    public void add(Integer value, int row, int col, int totalCols)
    {
        int index = row * totalCols + col;
        intMap.put(index, Objects.requireNonNullElse(value, 0));
    }

    @Override
    public void add(Function<Integer, Integer> function, DataStore<Integer> store) {
        final int rowInStore = store.getRows();
        final int colInStore = store.getCols();

        for(int indexRow = 0 ; indexRow < rowInStore; ++indexRow )
        {
            for (int indexCol = 0; indexCol < colInStore; ++indexCol)
            {
                Integer value = store.getValueAt(indexRow,indexCol);
                System.out.printf("Row: %d Col: %d Value: %d\n", indexRow, indexCol, value);
                value = function.apply(value);
                add(value, indexRow, indexCol, colInStore);
            }
        }
    }

    @Override
    public Integer getResult()
    {
        int sumValues = 0;
        for(Entry mapElement : intMap.entrySet())
        {
            int value =((int)mapElement.getValue());
            sumValues += value;
        }
        return sumValues;
    }
}
