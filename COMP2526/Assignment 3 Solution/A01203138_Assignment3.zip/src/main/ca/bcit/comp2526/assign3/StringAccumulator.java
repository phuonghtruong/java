package ca.bcit.comp2526.assign3;

import java.util.*;
import java.util.Map.Entry;
import java.util.function.Function;

public class StringAccumulator implements Accumulator<String, String>{
    Map<Integer, String> strMap;

    public StringAccumulator()
    {
        strMap = new HashMap<>();
        strMap.put(0,"");
    }

    public void add(String value, int row, int col, int totalCols)
    {
        int index = row * totalCols + col;
        strMap.put(index, Objects.requireNonNullElse(value, ""));
    }

    @Override
    public void add(Function<String, String> function, DataStore<String> store) {
        final int rowInStore = store.getRows();
        final int colInStore = store.getCols();

        for(int indexRow = 0 ; indexRow < rowInStore; ++indexRow )
        {
            for (int indexCol = 0; indexCol < colInStore; ++indexCol)
            {
                String value = store.getValueAt(indexRow,indexCol);
                System.out.printf("Row: %d Col: %d Value: %s\n", indexRow, indexCol, value);
                value = function.apply(value);
                add(value, indexRow, indexCol, colInStore);
            }
        }
    }

    @Override
    public String getResult()
    {
        String sumValues = "";
        for(Entry mapElement : strMap.entrySet())
        {
            String valueElement = mapElement.getValue().toString();
            if ((valueElement.isBlank() || valueElement.isEmpty()))
            {
                valueElement = " ";
            }
            sumValues = String.join(" ", sumValues, valueElement);
        }
        sumValues = sumValues.trim();
        if(!sumValues.isEmpty()) {
            sumValues = sumValues.replace("  ", " ");
            sumValues = sumValues.replace(" ", ", ");
            sumValues = sumValues.replace(",,",",");
        }
        return sumValues;
    }
}
